import{r as s,j as t}from"./chunk-CWUYAg6U.js";const a=s.forwardRef((r,o)=>t.jsx("b",{...r,ref:o}));a.displayName="Bold";export{a as f};
